import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

#x,y= np.loadtxt('part-r-00000.txt', delimiter=' ', unpack=True,skiprows=1,usecols=(2,3))

df= pd.read_csv('/home/akash/Downloads/part-r-00000',  sep='\s+', engine='python',usecols=['yyyymmdd','temp'])
x=df.yyyymmdd
y=df.temp
plt.plot(x,y, marker='o')

plt.title('Data from the part-r-00000 hadoop  File: Date and temp')

plt.xlabel('yyyymmdd')
plt.ylabel('temperature')



#plt.show()
#plt.title(“Global Land and Ocean Temperature Anomalies, June”)
#plt.xlabel('yyyymmdd')
#plt.ylabel('temp')
#plt.bar(data['2'], data[''], color="blue")
plt.show()
